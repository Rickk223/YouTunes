package youtunes.service.dao;

import youtunes.model.Album;
import youtunes.service.GenericDao;


public interface AlbumDao extends GenericDao<Album, Long> {

}