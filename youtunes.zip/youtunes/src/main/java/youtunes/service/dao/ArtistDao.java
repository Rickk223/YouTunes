package youtunes.service.dao;

import youtunes.model.Artist;
import youtunes.service.GenericDao;

public interface ArtistDao extends GenericDao<Artist, Long> {

}